package dev.realweather.config;

import net.neoforged.neoforge.common.ModConfigSpec;

/** Клиентская конфигурация (качество и визуальные параметры). */
public final class ClientConfig {
    public static final ModConfigSpec SPEC;

    public static final ModConfigSpec.BooleanValue ENABLED;
    public static final ModConfigSpec.EnumValue<Quality> QUALITY;
    public static final ModConfigSpec.BooleanValue CUSTOM_SKY;
    public static final ModConfigSpec.BooleanValue AMBIENT_CLOUDS;
    public static final ModConfigSpec.BooleanValue STORM_CLOUDS;
    public static final ModConfigSpec.DoubleValue CLOUD_DENSITY;
    public static final ModConfigSpec.DoubleValue CONTRAST;
    public static final ModConfigSpec.DoubleValue VIEW_DISTANCE;
    public static final ModConfigSpec.BooleanValue DEBRIS;
    public static final ModConfigSpec.BooleanValue CLOUD_SHADOWS;
    public static final ModConfigSpec.BooleanValue AUTO_QUALITY;
    public static final ModConfigSpec.BooleanValue CLOUD_VARIETY;
    public static final ModConfigSpec.IntValue CLOUD_REGIME;
    public static final ModConfigSpec.DoubleValue FUNNEL_SCALE;
    public static final ModConfigSpec.DoubleValue STORM_DARKNESS;
    public static final ModConfigSpec.DoubleValue REALISM;
    public static final ModConfigSpec.IntValue DETAIL;
    public static final ModConfigSpec.DoubleValue STEP_QUALITY;
    public static final ModConfigSpec.DoubleValue COVERAGE;
    public static final ModConfigSpec.DoubleValue CLOUD_SPEED;
    public static final ModConfigSpec.BooleanValue DISABLE_VANILLA_CLOUDS;

    static {
        ModConfigSpec.Builder b = new ModConfigSpec.Builder();
        ENABLED = b.comment("Главный выключатель клиентского рендера").define("enabled", true);
        QUALITY = b.comment("Профиль качества: LOW / MEDIUM / HIGH / ULTRA").defineEnum("quality", Quality.MEDIUM);
        CUSTOM_SKY = b.comment("Процедурное небо (замена ванильного неба в Оверворлде)").define("customSky", true);
        AMBIENT_CLOUDS = b.comment("Фоновые облака (кучевые + перистые) в небе").define("ambientClouds", true);
        STORM_CLOUDS = b.comment("Объёмные облака штормов").define("stormClouds", true);
        CLOUD_DENSITY = b.comment("Плотность штормовых облаков").defineInRange("cloudDensity", 1.0, 0.3, 2.5);
        CONTRAST = b.comment("Контраст света/тени в облаках").defineInRange("contrast", 1.0, 0.5, 1.8);
        VIEW_DISTANCE = b.comment("Дальность отрисовки штормов в блоках (ограничивается профилем качества)").defineInRange("viewDistance", 6000.0, 500.0, 8000.0);
        REALISM = b.comment("Реалистичность штормовых облаков: 0 = гладкие и мягкие, 1 = рваные, с мелкими деталями и сильным контрастом").defineInRange("realism", 0.35, 0.0, 1.0);
        DETAIL = b.comment("Добавка к числу октав шума облаков (-1 быстрее, +1 детальнее)").defineInRange("detailOffset", 0, -1, 1);
        STEP_QUALITY = b.comment("Качество марширования: 0.5 = быстро и грубо, 2 = медленно и гладко").defineInRange("stepQuality", 1.0, 0.5, 2.0);
        COVERAGE = b.comment("Множитель покрытия неба кучевыми облаками").defineInRange("cloudCoverage", 1.0, 0.4, 1.6);
        CLOUD_SPEED = b.comment("Скорость дрейфа облаков (0 = стоят)").defineInRange("cloudSpeed", 1.0, 0.0, 4.0);
        STORM_DARKNESS = b.comment("Сила затемнения неба под штормом (0 = не темнеет, 1 = полностью)").defineInRange("stormDarkness", 0.7, 0.0, 1.0);
        FUNNEL_SCALE = b.comment("Визуальная толщина воронки торнадо (на физику не влияет)").defineInRange("funnelScale", 1.3, 0.5, 2.5);
        CLOUD_VARIETY = b.comment("Разные виды облаков в разные дни (выкл. = всегда малая кучевая облачность)").define("cloudVariety", true);
        CLOUD_REGIME = b.comment("Принудительный вид облаков: -1 = по дням; 0 ясно, 1 кучевые малые, 2 кучевые мощные, 3 слоисто-кучевые, 4 слоистые, 5 высококучевые, 6 высокослоистые, 7 перистые, 8 перистослоистые (гало), 9 перисто-кучевые, 10 линзовидные, 11 смешанный, 12 пасмурно (слоисто-дождевые)").defineInRange("cloudRegime", -1, -1, 12);
        AUTO_QUALITY = b.comment("Автокачество: при низком FPS мод сам снижает число шагов облаков, при высоком возвращает").define("autoQuality", true);
        CLOUD_SHADOWS = b.comment("Тени облаков на земле").define("cloudShadows", true);
        DEBRIS = b.comment("Частицы обломков вокруг торнадо").define("debrisParticles", true);
        DISABLE_VANILLA_CLOUDS = b.comment("Выключать ванильные облака при входе в мир (они перекрывают наши)").define("disableVanillaClouds", true);
        SPEC = b.build();
    }

    private ClientConfig() {}
}
