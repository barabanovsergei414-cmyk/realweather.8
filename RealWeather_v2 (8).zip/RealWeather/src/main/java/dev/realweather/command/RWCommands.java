package dev.realweather.command;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.FloatArgumentType;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.minecraft.commands.SharedSuggestionProvider;
import dev.realweather.cm1.Cm1Loader;
import dev.realweather.cm1.Cm1Manager;
import dev.realweather.cm1.Cm1Runner;
import dev.realweather.config.RWConfig;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import dev.realweather.storm.Storm;
import dev.realweather.storm.StormManager;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.event.RegisterCommandsEvent;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

/** /realweather storm|tornado|intensity|clear|info (нужен уровень доступа 2). */
public final class RWCommands {
    private RWCommands() {}

    public static void register(RegisterCommandsEvent e) {
        CommandDispatcher<CommandSourceStack> d = e.getDispatcher();
        d.register(Commands.literal("realweather").requires(s -> s.hasPermission(2))
                .then(Commands.literal("storm")
                        .executes(c -> spawn(c, 0.9f, false, -1, -1))
                        .then(Commands.argument("intensity", FloatArgumentType.floatArg(0.1f, 1f))
                                .executes(c -> spawn(c, FloatArgumentType.getFloat(c, "intensity"), false, -1, -1))))
                .then(Commands.literal("tornado")
                        .executes(c -> spawn(c, 1f, true, -1, -1))
                        .then(Commands.argument("ef", IntegerArgumentType.integer(0, 5))
                                .executes(c -> spawn(c, 1f, true, IntegerArgumentType.getInteger(c, "ef"), -1))
                                .then(Commands.argument("shape", StringArgumentType.word())
                                        .suggests((ctx, sb) -> SharedSuggestionProvider.suggest(
                                                new String[]{"auto", "rope", "cone", "stovepipe", "wedge"}, sb))
                                        .executes(c -> spawn(c, 1f, true, IntegerArgumentType.getInteger(c, "ef"),
                                                shapeIdx(StringArgumentType.getString(c, "shape")))))))
                .then(Commands.literal("supercell")
                        .executes(c -> spawnCm1(c, RWConfig.CAPE.get().floatValue(), RWConfig.SHEAR.get().floatValue()))
                        .then(Commands.argument("cape", IntegerArgumentType.integer(300, 6000))
                                .then(Commands.argument("shear", IntegerArgumentType.integer(0, 40))
                                        .executes(c -> spawnCm1(c, IntegerArgumentType.getInteger(c, "cape"),
                                                IntegerArgumentType.getInteger(c, "shear"))))))
                .then(Commands.literal("cm1")
                        .then(Commands.literal("start").executes(c -> cm1Start(c, true)))
                        .then(Commands.literal("load").executes(c -> cm1Start(c, false)))
                        .then(Commands.literal("stop").executes(RWCommands::cm1Stop))
                        .then(Commands.literal("status").executes(RWCommands::cm1Status))
                        .then(Commands.literal("inspect").executes(c -> cm1Inspect(c, null))
                                .then(Commands.argument("file", StringArgumentType.greedyString())
                                        .executes(c -> cm1Inspect(c, StringArgumentType.getString(c, "file")))))
                        .then(Commands.literal("speed").then(Commands.argument("x", FloatArgumentType.floatArg(0.1f, 60f))
                                .executes(c -> {
                                    Cm1Manager.setSpeed(FloatArgumentType.getFloat(c, "x"));
                                    c.getSource().sendSuccess(() -> Component.literal("Скорость воспроизведения CM1 изменена"), true);
                                    return 1;
                                })))
                        .then(Commands.literal("track")
                                .then(Commands.literal("updraft").executes(c -> { Cm1Manager.setTrackMode(0); return 1; }))
                                .then(Commands.literal("tornado").executes(c -> { Cm1Manager.setTrackMode(1); return 1; }))))
                .then(Commands.literal("type")
                        .then(Commands.argument("name", StringArgumentType.word())
                                .suggests((ctx, sb) -> SharedSuggestionProvider.suggest(
                                        new String[]{"random", "classic", "hp", "lp", "multicell", "single"}, sb))
                                .executes(c -> setType(c, StringArgumentType.getString(c, "name")))))
                .then(Commands.literal("intensity")
                        .then(Commands.argument("value", FloatArgumentType.floatArg(0.1f, 1f))
                                .executes(c -> setIntensity(c, FloatArgumentType.getFloat(c, "value")))))
                .then(Commands.literal("clear").executes(RWCommands::clear))
                .then(Commands.literal("info").executes(RWCommands::info)));
    }

    private static ServerLevel overworld(CommandContext<CommandSourceStack> c) {
        ServerLevel l = c.getSource().getLevel();
        return l.dimension() == Level.OVERWORLD ? l : null;
    }

    private static int shapeIdx(String n) {
        return switch (n.toLowerCase()) {
            case "rope" -> 0;
            case "cone" -> 1;
            case "stovepipe" -> 2;
            case "wedge" -> 3;
            default -> -1;
        };
    }

    private static int spawn(CommandContext<CommandSourceStack> c, float intensity, boolean tornado, int ef, int shape) throws CommandSyntaxException {
        ServerPlayer p = c.getSource().getPlayerOrException();
        ServerLevel level = overworld(c);
        if (level == null) {
            c.getSource().sendFailure(Component.literal("RealWeather работает только в Оверворлде."));
            return 0;
        }
        Vec3 look = p.getLookAngle();
        double lx = look.x, lz = look.z;
        double len = Math.sqrt(lx * lx + lz * lz);
        if (len < 1e-4) { lx = 1; lz = 0; len = 1; }
        lx /= len; lz /= len;
        double dist = tornado ? 500 : 520;
        double x = p.getX() + lx * dist, z = p.getZ() + lz * dist;
        float heading = (float) Math.atan2(-lz, -lx);   // движется в сторону игрока
        Storm s = StormManager.spawn(level, x, z, heading, intensity, tornado, tornado ? 0.02 : 0.02,
                RWConfig.CAPE.get().floatValue(), RWConfig.SHEAR.get().floatValue(), tornado ? 8.0 : 6.0);
        if (s == null) {
            c.getSource().sendFailure(Component.literal("Достигнут лимит штормов (maxStorms)."));
            return 0;
        }
        if (tornado) s.setTornadoSpec(ef, shape);
        c.getSource().sendSuccess(() -> Component.literal(
                (tornado ? "Торнадическая суперячейка (CM1-сценарий ~8 мин: пузырь → башня → мезоциклон → торнадо)" : "Шторм (рост с нуля)") + ", " + (int) dist
                        + " блоков впереди, интенсивность " + String.format("%.2f", intensity)), true);
        return 1;
    }

    /** Сценарий в духе CM1: тёплый пузырь у земли, дальше шторм развивается сам (торнадо через несколько минут). */
    private static int spawnCm1(CommandContext<CommandSourceStack> c, float cape, float shear) throws CommandSyntaxException {
        ServerPlayer p = c.getSource().getPlayerOrException();
        ServerLevel level = overworld(c);
        if (level == null) return 0;
        Vec3 look = p.getLookAngle();
        double lx = look.x, lz = look.z;
        double len = Math.sqrt(lx * lx + lz * lz);
        if (len < 1e-4) { lx = 1; lz = 0; len = 1; }
        lx /= len; lz /= len;
        double x = p.getX() + lx * 650, z = p.getZ() + lz * 650;
        float heading = (float) Math.atan2(-lz, -lx);
        Storm s = StormManager.spawn(level, x, z, heading, 1f, shear >= 10f, 0.02, cape, shear, 0.0);
        if (s == null) {
            c.getSource().sendFailure(Component.literal("Достигнут лимит штормов (maxStorms)."));
            return 0;
        }
        c.getSource().sendSuccess(() -> Component.literal("Суперячейка (CM1-подобный сценарий): CAPE " + (int) cape
                + " Дж/кг, сдвиг " + (int) shear + " м/с. Торнадо — "
                + (s.tornadic ? "ожидается через несколько минут" : "не ожидается (мал сдвиг)")), true);
        return 1;
    }

    private static String[] list(String s) {
        return s.split("\\s*,\\s*");
    }

    private static Path cm1OutDir() {
        String od = RWConfig.CM1_OUTPUT_DIR.get().trim();
        if (od.isEmpty()) od = RWConfig.CM1_WORKDIR.get().trim();
        return od.isEmpty() ? null : Paths.get(od);
    }

    private static int cm1Start(CommandContext<CommandSourceStack> c, boolean launch) throws CommandSyntaxException {
        ServerPlayer p = c.getSource().getPlayerOrException();
        ServerLevel level = overworld(c);
        if (level == null) {
            c.getSource().sendFailure(Component.literal("CM1 работает только в Оверворлде."));
            return 0;
        }
        if (!RWConfig.CM1_ENABLED.get()) {
            c.getSource().sendFailure(Component.literal("Интеграция CM1 выключена: поставьте enabled = true в секции [cm1] файла realweather-server.toml."));
            return 0;
        }
        if (c.getSource().getServer().isDedicatedServer() && !RWConfig.CM1_ALLOW_DEDICATED.get()) {
            c.getSource().sendFailure(Component.literal("На выделенном сервере облака CM1 клиентам не передаются. Разрешить всё равно: allowDedicatedServer = true."));
            return 0;
        }
        Path out = cm1OutDir();
        if (out == null || !Files.isDirectory(out)) {
            c.getSource().sendFailure(Component.literal("Папка вывода CM1 не найдена (outputDir/workDir в [cm1]): " + out));
            return 0;
        }
        Cm1Loader.Params prm = new Cm1Loader.Params();
        prm.cloud = list(RWConfig.CM1_VAR_CLOUD.get());
        prm.rain = list(RWConfig.CM1_VAR_RAIN.get());
        prm.u = list(RWConfig.CM1_VAR_U.get());
        prm.v = list(RWConfig.CM1_VAR_V.get());
        prm.w = list(RWConfig.CM1_VAR_W.get());
        prm.xName = RWConfig.CM1_VAR_X.get().trim();
        prm.yName = RWConfig.CM1_VAR_Y.get().trim();
        prm.zName = RWConfig.CM1_VAR_Z.get().trim();
        prm.windowCells = RWConfig.CM1_WINDOW.get();
        prm.stride = RWConfig.CM1_STRIDE.get();
        prm.maxLevels = RWConfig.CM1_LEVELS.get();
        prm.zTopKm = RWConfig.CM1_ZTOP.get();
        prm.trackMode = RWConfig.CM1_TRACK.get();
        Vec3 look = p.getLookAngle();
        double lx = look.x, lz = look.z, len = Math.sqrt(lx * lx + lz * lz);
        if (len < 1e-4) { lx = 1; lz = 0; len = 1; }
        double ahead = RWConfig.CM1_AHEAD.get();
        double ax = p.getX() + lx / len * ahead, az = p.getZ() + lz / len * ahead;
        StormManager.clear(level);                       // игровые штормы отключаем: в мире только CM1
        Cm1Manager.start(out, RWConfig.CM1_PATTERN.get(), prm, RWConfig.CM1_MPB.get(), RWConfig.CM1_VSCALE.get(),
                RWConfig.CM1_SPEED.get(), RWConfig.CM1_GROUND_Y.get(), ax, az, RWConfig.CM1_WIND_GAIN.get());
        if (launch) {
            try {
                Cm1Runner.start(RWConfig.CM1_COMMAND.get(), RWConfig.CM1_WORKDIR.get().trim());
            } catch (java.io.IOException e) {
                Cm1Manager.stop();
                c.getSource().sendFailure(Component.literal("Не удалось запустить CM1: " + e.getMessage()));
                return 0;
            }
        }
        c.getSource().sendSuccess(() -> Component.literal((launch ? "CM1 запущен. " : "")
                + "Жду выходные файлы в " + out + " (маска " + RWConfig.CM1_PATTERN.get() + "). Шторм появится в ~"
                + (int) ahead + " блоках впереди, когда прочитается первый кадр. Статус: /realweather cm1 status"), true);
        return 1;
    }

    private static int cm1Stop(CommandContext<CommandSourceStack> c) {
        Cm1Runner.stop();
        Cm1Manager.stop();
        c.getSource().sendSuccess(() -> Component.literal("CM1 остановлен, воспроизведение выключено."), true);
        return 1;
    }

    private static int cm1Status(CommandContext<CommandSourceStack> c) {
        String m = "Процесс CM1: " + (Cm1Runner.isRunning() ? "работает" : "не запущен")
                + (Cm1Runner.lastLine().isEmpty() ? "" : " (последняя строка: " + Cm1Runner.lastLine() + ")")
                + "\nВоспроизведение: " + (Cm1Manager.active() ? Cm1Manager.status() : "выключено");
        c.getSource().sendSuccess(() -> Component.literal(m), false);
        return 1;
    }

    private static int cm1Inspect(CommandContext<CommandSourceStack> c, String name) {
        Path out = cm1OutDir();
        if (out == null || !Files.isDirectory(out)) {
            c.getSource().sendFailure(Component.literal("Папка вывода CM1 не найдена."));
            return 0;
        }
        try {
            Path f;
            if (name == null) {
                f = null;
                try (var ds = Files.newDirectoryStream(out, RWConfig.CM1_PATTERN.get())) {
                    for (Path p : ds) if (f == null || p.getFileName().toString().compareTo(f.getFileName().toString()) > 0) f = p;
                }
                if (f == null) {
                    c.getSource().sendFailure(Component.literal("Нет файлов по маске " + RWConfig.CM1_PATTERN.get() + " в " + out));
                    return 0;
                }
            } else {
                f = out.resolve(name).normalize();
                if (!f.startsWith(out.normalize())) {
                    c.getSource().sendFailure(Component.literal("Файл должен лежать в папке вывода CM1."));
                    return 0;
                }
            }
            String d = Cm1Loader.inspect(f);
            c.getSource().sendSuccess(() -> Component.literal(f.getFileName() + "\n" + d), false);
            return 1;
        } catch (java.io.IOException e) {
            c.getSource().sendFailure(Component.literal("Ошибка чтения: " + e.getMessage()));
            return 0;
        }
    }

    private static int setType(CommandContext<CommandSourceStack> c, String n) {
        int t = switch (n.toLowerCase()) {
            case "classic" -> 0;
            case "hp" -> 1;
            case "lp" -> 2;
            case "multicell" -> 3;
            case "single" -> 4;
            default -> -1;
        };
        StormManager.forcedType = t;
        c.getSource().sendSuccess(() -> Component.literal(t < 0 ? "Тип следующих штормов: случайный"
                : "Тип следующих штормов: " + StormManager.typeName(t)
                + (t > 2 ? " (торнадо у такого типа нет; команда tornado выберет суперячейку)" : "")), true);
        return 1;
    }

    private static int setIntensity(CommandContext<CommandSourceStack> c, float v) {
        ServerLevel level = overworld(c);
        if (level == null) return 0;
        for (Storm s : StormManager.get(level)) s.goal = Mth.clamp(v, 0.1f, 1f);
        c.getSource().sendSuccess(() -> Component.literal("Целевая интенсивность: " + v), true);
        return 1;
    }

    private static int clear(CommandContext<CommandSourceStack> c) {
        ServerLevel level = overworld(c);
        if (level == null) return 0;
        StormManager.clear(level);
        c.getSource().sendSuccess(() -> Component.literal("Все штормы удалены."), true);
        return 1;
    }

    private static int info(CommandContext<CommandSourceStack> c) {
        ServerLevel level = overworld(c);
        if (level == null) return 0;
        List<Storm> list = StormManager.get(level);
        if (list.isEmpty()) {
            c.getSource().sendSuccess(() -> Component.literal("Штормов нет."), false);
            return 0;
        }
        for (Storm s : list) {
            String m = String.format("#%d [%s] (%.0f, %.0f) возраст %d/%d с, интенсивность %.2f, торнадо %.2f, рост %.2f, скорость %.1f бл/с",
                    s.st.id, StormManager.typeName(s.st.type), s.st.x, s.st.z, s.age / 20, s.life / 20, s.st.intensity, s.st.tornado, s.st.growth, s.st.speed * 20);
            c.getSource().sendSuccess(() -> Component.literal(m), false);
        }
        return list.size();
    }
}
