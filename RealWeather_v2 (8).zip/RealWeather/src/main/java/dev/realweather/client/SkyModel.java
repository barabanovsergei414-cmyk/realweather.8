package dev.realweather.client;

import dev.realweather.MathUtil;
import dev.realweather.config.ClientConfig;
import net.minecraft.client.multiplayer.ClientLevel;

/**
 * Палитра неба, рассчитываемая непрерывно из высоты солнца и грозового затемнения (никаких
 * жёстких переключений день/вечер/ночь). Те же значения идут в шейдеры неба/облаков и в цвет тумана.
 * Все цвета линейные; тонемаппинг tm(c)=1-exp(-1.2c) одинаков в шейдерах и здесь.
 */
public final class SkyModel {
    public static final SkyModel INSTANCE = new SkyModel();

    public final float[] sunDir = new float[3];
    public final float[] zenith = new float[3];
    public final float[] horizon = new float[3];
    public final float[] sunColor = new float[3];
    public final float[] ambient = new float[3];
    public final float[] glow = new float[3];
    public float day, night, twilight, darkness, sunH;
    /** Погода дня: покрытие кучевыми (0..1), доля перистых, фаза шума облаков. */
    public float dayVar, cirrus, dayPhase;
    /** Слои облаков дня: кучевые, «башенность», слоисто-кучевые, слоистые, высококучевые, высокослоистые,
     *  перистые, перистослоистые, перисто-кучевые, линзовидные; overcast — общая пасмурность. */
    public float cumAmt, towering, scAmt, stratusAmt, acAmt, asAmt, cirrusAmt, csAmt, ccAmt, lentAmt, overcast;
    private final float[] lay = new float[10];

    private static final float[][] REGIMES = {
            // cum   tow    sc     st     ac     as     ci     cs     cc     lent
            {0.08f, 0.20f, 0f,    0f,    0f,    0f,    0.15f, 0f,    0f,    0f},     // 0 ясно
            {0.35f, 0.15f, 0f,    0f,    0f,    0f,    0.20f, 0f,    0f,    0f},     // 1 малые кучевые
            {0.55f, 0.90f, 0f,    0f,    0.10f, 0f,    0.15f, 0f,    0f,    0f},     // 2 мощные кучевые
            {0.10f, 0.20f, 0.85f, 0f,    0f,    0f,    0f,    0f,    0f,    0f},     // 3 слоисто-кучевые
            {0f,    0f,    0.20f, 0.90f, 0f,    0f,    0f,    0f,    0f,    0f},     // 4 слоистые
            {0.05f, 0.20f, 0f,    0f,    0.85f, 0f,    0.20f, 0f,    0f,    0f},     // 5 высококучевые
            {0f,    0f,    0f,    0f,    0f,    0.85f, 0.30f, 0.30f, 0f,    0f},     // 6 высокослоистые
            {0.10f, 0.20f, 0f,    0f,    0f,    0f,    0.95f, 0f,    0.30f, 0f},     // 7 перистые
            {0.05f, 0.20f, 0f,    0f,    0f,    0f,    0.40f, 0.90f, 0f,    0f},     // 8 перистослоистые + гало
            {0.25f, 0.30f, 0f,    0f,    0f,    0f,    0.10f, 0f,    0.85f, 0f},     // 9 перисто-кучевые
            {0.10f, 0.30f, 0f,    0f,    0.30f, 0f,    0.10f, 0f,    0f,    0.85f}, // 10 линзовидные
            {0.40f, 0.50f, 0.20f, 0f,    0.40f, 0f,    0.50f, 0f,    0f,    0f},     // 11 смешанный
            {0f,    0f,    0.10f, 0.95f, 0f,    0.85f, 0f,    0f,    0f,    0f},     // 12 пасмурно
    };
    // «вес» режима: ясная и кучевая погода встречается чаще
    private static final float[] REGIME_W = {2.0f, 3.0f, 1.5f, 1.0f, 1.0f, 1.0f, 0.8f, 1.0f, 0.6f, 0.6f, 0.5f, 1.0f, 0.5f};

    private static int regimeOf(long day) {
        float total = 0f;
        for (float w : REGIME_W) total += w;
        float r = hashDay(day, 7) * total, acc = 0f;
        for (int i = 0; i < REGIME_W.length; i++) {
            acc += REGIME_W[i];
            if (r < acc) return i;
        }
        return 1;
    }

    /** Режим облаков дня; в конце суток плавно переходит к режиму следующего дня. */
    private void computeClouds(double dayF) {
        int cfg = ClientConfig.CLOUD_REGIME.get();
        if (!ClientConfig.CLOUD_VARIETY.get() && cfg < 0) cfg = 1;
        if (cfg >= 0) {
            System.arraycopy(REGIMES[cfg], 0, lay, 0, 10);
        } else {
            long d = (long) Math.floor(dayF);
            float f = (float) (dayF - d);
            float t = MathUtil.smooth(0.75f, 1.0f, f);
            float[] a = REGIMES[regimeOf(d)], b = REGIMES[regimeOf(d + 1)];
            for (int i = 0; i < 10; i++) lay[i] = MathUtil.lerp(a[i], b[i], t);
        }
        cumAmt = lay[0]; towering = lay[1]; scAmt = lay[2]; stratusAmt = lay[3]; acAmt = lay[4];
        asAmt = lay[5]; cirrusAmt = lay[6]; csAmt = lay[7]; ccAmt = lay[8]; lentAmt = lay[9];
        overcast = Math.min(1f, stratusAmt * 0.9f + asAmt * 0.7f + scAmt * 0.4f + csAmt * 0.25f);
    }

    private static final float[] NIGHT_Z = {0.006f, 0.010f, 0.030f};
    private static final float[] DAY_Z = {0.10f, 0.27f, 0.72f};
    private static final float[] NIGHT_H = {0.024f, 0.032f, 0.065f};
    private static final float[] DAY_H = {0.55f, 0.72f, 0.95f};
    private static final float[] TW_H = {0.85f, 0.34f, 0.14f};
    private static final float[] SUN_LOW = {1.0f, 0.40f, 0.15f};
    private static final float[] SUN_HIGH = {1.0f, 0.94f, 0.84f};
    private static final float[] AMB_NIGHT = {0.03f, 0.04f, 0.08f};
    private static final float[] AMB_DAY = {0.40f, 0.52f, 0.75f};
    private static final float[] STORM_Z = {0.20f, 0.23f, 0.26f};
    private static final float[] STORM_H = {0.42f, 0.46f, 0.44f};

    private SkyModel() {}

    private static float hashDay(long d, int ch) {
        long h = d * 374761393L + ch * 668265263L;
        h = (h ^ (h >>> 13)) * 1274126177L;
        return ((h ^ (h >>> 16)) & 0xFFFF) / 65535f;
    }

    /** Гладкая случайная кривая по дням: каждый день своя «погода», без скачков на границе суток. */
    private static float dayNoise(double dayF, int ch) {
        long d = (long) Math.floor(dayF);
        float f = (float) (dayF - d);
        f = f * f * (3f - 2f * f);
        return MathUtil.lerp(hashDay(d, ch), hashDay(d + 1, ch), f);
    }

    public void update(ClientLevel level, float pt, double cx, double cz, double now) {
        double dt = ClientStorms.dayTime(level, now);
        float tod = level.dimensionType().timeOfDay((long) dt);
        double th = tod * Math.PI * 2.0;
        double dayF = dt / 24000.0;
        dayVar = dayNoise(dayF, 0);
        cirrus = 0.15f + 0.85f * dayNoise(dayF, 1);
        dayPhase = (float) (dayF * 0.9);
        computeClouds(dayF);
        sunDir[0] = (float) -Math.sin(th);
        sunDir[1] = (float) Math.cos(th);
        sunDir[2] = 0f;
        sunH = sunDir[1];
        darkness = Math.max(ClientStorms.darknessAt(cx, cz, now), dev.realweather.cm1.Cm1Manager.darknessAt(cx, cz))
                * ClientConfig.STORM_DARKNESS.get().floatValue();

        day = MathUtil.smooth(-0.10f, 0.22f, sunH);
        night = 1f - MathUtil.smooth(-0.22f, 0.02f, sunH);
        float q = (sunH + 0.02f) / 0.16f;
        twilight = (float) Math.exp(-q * q);

        for (int i = 0; i < 3; i++) {
            zenith[i] = MathUtil.lerp(NIGHT_Z[i], DAY_Z[i], day);
            horizon[i] = MathUtil.lerp(NIGHT_H[i], DAY_H[i], day) + twilight * TW_H[i] * 0.55f;
            ambient[i] = MathUtil.lerp(AMB_NIGHT[i], AMB_DAY[i], day);
            glow[i] = twilight * SUN_LOW[i];
        }
        zenith[0] += twilight * 0.03f; zenith[1] += twilight * 0.02f; zenith[2] += twilight * 0.07f;
        ambient[0] += twilight * 0.22f; ambient[1] += twilight * 0.12f; ambient[2] += twilight * 0.10f;

        float sunVis = MathUtil.smooth(-0.08f, 0.06f, sunH);
        float warm = MathUtil.smooth(0.0f, 0.4f, sunH);
        for (int i = 0; i < 3; i++) {
            sunColor[i] = MathUtil.lerp(SUN_LOW[i], SUN_HIGH[i], warm) * sunVis * 1.2f;
        }

        // грозовое затемнение: небо уходит в серый, солнце гаснет
        float dk = Math.max(darkness, overcast * 0.65f);       // шторм или сплошная облачность
        float dayMix = 0.25f + 0.75f * day;
        for (int i = 0; i < 3; i++) {
            zenith[i] = MathUtil.lerp(zenith[i], STORM_Z[i] * dayMix, dk);
            horizon[i] = MathUtil.lerp(horizon[i], STORM_H[i] * (0.2f + 0.8f * day), dk * 0.85f);
            sunColor[i] *= 1f - 0.8f * dk;
            glow[i] *= 1f - dk;
            ambient[i] *= 1f - 0.45f * dk;
        }
    }

    /** Цвет тумана = тонемаппированный цвет горизонта (чтобы дальний рельеф сливался с небом). */
    public void fogColor(float[] out) {
        for (int i = 0; i < 3; i++) out[i] = 1f - (float) Math.exp(-horizon[i] * 1.2f);
    }
}
