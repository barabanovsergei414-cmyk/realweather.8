#version 150

uniform mat4 InvViewProj;
uniform sampler2D DepthSampler;
uniform sampler2D Atlas;
uniform vec3 CamPos;
uniform float Time;
uniform vec3 SunDir;
uniform vec3 SunColor;
uniform vec3 AmbientColor;
uniform vec3 HazeColor;
uniform float Steps;
uniform float StepScale;
uniform float MaxDist;
uniform float Density;
uniform float Contrast;
uniform float Realism;
uniform float FlashAmt;
uniform vec3 FlashPos;
uniform float Darkness;
uniform vec3 WinMin;      // угол окна: x,z — относительно камеры, y — абсолютная высота
uniform vec3 WinSize;     // размеры окна в блоках: x, высота, z
uniform vec4 Grid;        // nx, ny, nz, число плиток по X в атласе
uniform vec2 AtlasSize;

in vec2 ndc;
out vec4 fragColor;

float ss(float a, float b, float x) { return clamp((x - a) / (b - a), 0.0, 1.0); }

float hash13(vec3 p3) {
    p3 = fract(p3 * 0.1031);
    p3 += dot(p3, p3.zyx + 31.32);
    return fract((p3.x + p3.y) * p3.z);
}

float vnoise(vec3 x) {
    vec3 i = floor(x);
    vec3 f = fract(x);
    f = f * f * (3.0 - 2.0 * f);
    return mix(mix(mix(hash13(i), hash13(i + vec3(1, 0, 0)), f.x),
                   mix(hash13(i + vec3(0, 1, 0)), hash13(i + vec3(1, 1, 0)), f.x), f.y),
               mix(mix(hash13(i + vec3(0, 0, 1)), hash13(i + vec3(1, 0, 1)), f.x),
                   mix(hash13(i + vec3(0, 1, 1)), hash13(i + vec3(1, 1, 1)), f.x), f.y), f.z);
}

float fbm(vec3 p, int oct) {
    float a = 0.5;
    float s = 0.0;
    for (int i = 0; i < oct; i++) {
        s += a * vnoise(p);
        p = p * 2.02 + vec3(17.1, 3.7, 9.2);
        a *= 0.5;
    }
    return s;
}

vec2 rot(vec2 v, float a) {
    float c = cos(a);
    float s = sin(a);
    return vec2(c * v.x - s * v.y, s * v.x + c * v.y);
}

vec3 tm(vec3 c) { return 1.0 - exp(-c * 1.2); }

float hgN(float c, float g) {
    float g2 = g * g;
    return (1.0 - g2) / pow(1.0 + g2 - 2.0 * g * c, 1.5);
}

vec4 slice(float k, vec2 cuv) {
    float tx = mod(k, Grid.w);
    float ty = floor(k / Grid.w);
    vec2 px = clamp(cuv * Grid.xy, vec2(0.5), Grid.xy - vec2(0.5));
    vec2 uv = (vec2(tx, ty) * Grid.xy + px) / AtlasSize;
    return texture(Atlas, uv);
}

// (облачная вода, дождевая вода, апдрафт) в 0..1; значения в атласе хранятся как sqrt()
vec3 vol(vec3 p) {
    vec3 q = (p - WinMin) / WinSize;
    if (q.x < 0.0 || q.x > 1.0 || q.y < 0.0 || q.y > 1.0 || q.z < 0.0 || q.z > 1.0) return vec3(0.0);
    float fk = q.y * Grid.z - 0.5;
    float k0 = floor(fk);
    float f = fk - k0;
    vec4 a = slice(clamp(k0, 0.0, Grid.z - 1.0), q.xz);
    vec4 b = slice(clamp(k0 + 1.0, 0.0, Grid.z - 1.0), q.xz);
    vec4 s = mix(a, b, f);
    return vec3(s.r * s.r, s.g * s.g, s.b);
}

vec2 boxHit(vec3 ro, vec3 rd, vec3 bmin, vec3 bmax) {
    vec3 sg = vec3(rd.x < 0.0 ? -1.0 : 1.0, rd.y < 0.0 ? -1.0 : 1.0, rd.z < 0.0 ? -1.0 : 1.0);
    vec3 inv = sg / max(abs(rd), vec3(1e-5));
    vec3 t0 = (bmin - ro) * inv;
    vec3 t1 = (bmax - ro) * inv;
    vec3 tn = min(t0, t1);
    vec3 tf = max(t0, t1);
    return vec2(max(max(tn.x, tn.y), tn.z), min(min(tf.x, tf.y), tf.z));
}

void main() {
    vec4 far = InvViewProj * vec4(ndc, 1.0, 1.0);
    vec3 rd = normalize(far.xyz / far.w);
    vec3 ro = vec3(0.0, CamPos.y, 0.0);

    float tDepth = 1e9;
    float dsmp = texture(DepthSampler, ndc * 0.5 + 0.5).r;
    if (dsmp < 0.99999) {
        vec4 wp = InvViewProj * vec4(ndc, dsmp * 2.0 - 1.0, 1.0);
        tDepth = length(wp.xyz / wp.w);
    }
    vec2 hit = boxHit(ro, rd, WinMin, WinMin + WinSize);
    float tmin = max(hit.x, 0.0);
    float tmax = min(hit.y, min(tDepth, MaxDist));
    if (hit.y <= hit.x || tmax <= tmin) {
        fragColor = vec4(0.0);
        return;
    }

    float jit = fract(52.9829189 * fract(dot(gl_FragCoord.xy, vec2(0.06711056, 0.00583715))));
    float t = tmin + jit * clamp(tmin * StepScale, 3.0, 40.0);
    vec3 acc = vec3(0.0);
    float T = 1.0;
    float cosSun = dot(rd, SunDir);
    float phase = min(mix(hgN(cosSun, -0.2), hgN(cosSun, 0.62), 0.35), 6.0);
    float used = 0.0;

    for (int i = 0; i < 256; i++) {
        if (used >= Steps * 1.5 || t > tmax) break;
        vec3 p = ro + rd * t;
        float sl = clamp(t * StepScale, 3.0, 40.0);
        used += 1.0;

        vec3 v = vol(p);
        float c = clamp(v.x * 6.0, 0.0, 1.0);
        float rainD = clamp(v.y * 3.0, 0.0, 1.0) * 0.35;
        if (c > 0.01) {
            vec3 pl = p - WinMin;
            float n = fbm(pl * 0.06, 3);
            c = clamp(c - (1.0 - n) * 0.25 * Realism * (1.0 - 0.5 * c), 0.0, 1.0);
        }
        float dens = c + rainD;

        if (dens > 0.003) {
            float hN = clamp((p.y - WinMin.y) / WinSize.y, 0.0, 1.0);
            float tauL = 0.0;
            for (int j = 1; j <= 3; j++) {
                float dd = 30.0 * pow(2.1, float(j - 1));
                tauL += vol(p + SunDir * dd).x * 6.0 * dd * 0.5;
            }
            float E = exp(-tauL * 0.015 * Density);
            float lit = E * phase + 0.30 * pow(E, 0.25);
            float rf = clamp(rainD / max(dens, 1e-3), 0.0, 1.0);
            vec3 albedo = mix(vec3(1.0), vec3(0.50, 0.54, 0.58), rf * 0.8);
            float under = pow(1.0 - hN, 1.5);
            float rainLoad = clamp(v.y * 3.0, 0.0, 1.0);
            float ambF = mix(0.45, 1.0, smoothstep(0.0, 0.8, hN));
            ambF *= mix(1.0, 0.25, clamp(0.4 + rainLoad * 0.6, 0.0, 1.0) * under);
            vec3 amb = AmbientColor * ambF * mix(0.55, 1.0, E);
            vec3 sunL = SunColor * lit * Contrast * (0.8 + 0.4 * Realism) * 0.85 * mix(1.0, 0.30, rainLoad * under);
            vec3 fl = vec3(0.65, 0.78, 1.0) * FlashAmt * exp(-length(p - FlashPos) / 420.0) * (2.0 + 3.0 * under);
            vec3 col = albedo * (sunL + amb + fl);
            col = mix(col, HazeColor, (1.0 - exp(-t * 0.00030)) * 0.6);
            float fade = 1.0 - ss(0.7 * MaxDist, MaxDist, t);
            float a = 1.0 - exp(-dens * 0.06 * Density * fade * sl);
            acc += T * a * col;
            T *= (1.0 - a);
            if (T < 0.02) break;
            t += sl * 0.75;
        } else {
            t += sl * 1.5;
        }
    }
    fragColor = vec4(tm(acc), 1.0 - T);
}
