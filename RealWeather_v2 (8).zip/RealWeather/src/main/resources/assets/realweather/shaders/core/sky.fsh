#version 150

uniform mat4 InvViewProj;
uniform vec3 CamPos;
uniform float Time;
uniform vec3 SunDir;
uniform vec3 SunColor;
uniform vec3 ZenithColor;
uniform vec3 HorizonColor;
uniform vec3 GlowColor;
uniform vec3 AmbientColor;
uniform float Night;
uniform float Darkness;
uniform vec2 WindOffset;
uniform float FlashAmt;
uniform float CloudSteps;
uniform float AmbientCloud;
uniform float CirrusAmt;
uniform vec4 Mix1;      // слоисто-кучевые, слоистые, высококучевые, высокослоистые
uniform vec4 Mix2;      // перистые, перистослоистые, перисто-кучевые, линзовидные
uniform float CumAmt;

in vec2 ndc;
out vec4 fragColor;

float ss(float a, float b, float x) { return clamp((x - a) / (b - a), 0.0, 1.0); }

float hash13(vec3 p3) {
    p3 = fract(p3 * 0.1031);
    p3 += dot(p3, p3.zyx + 31.32);
    return fract((p3.x + p3.y) * p3.z);
}

float vnoise(vec3 x) {
    vec3 i = floor(x);
    vec3 f = fract(x);
    f = f * f * (3.0 - 2.0 * f);
    return mix(mix(mix(hash13(i), hash13(i + vec3(1, 0, 0)), f.x),
                   mix(hash13(i + vec3(0, 1, 0)), hash13(i + vec3(1, 1, 0)), f.x), f.y),
               mix(mix(hash13(i + vec3(0, 0, 1)), hash13(i + vec3(1, 0, 1)), f.x),
                   mix(hash13(i + vec3(0, 1, 1)), hash13(i + vec3(1, 1, 1)), f.x), f.y), f.z);
}

float fbm(vec3 p, int oct) {
    float a = 0.5;
    float s = 0.0;
    for (int i = 0; i < oct; i++) {
        s += a * vnoise(p);
        p = p * 2.02 + vec3(17.1, 3.7, 9.2);
        a *= 0.5;
    }
    return s;
}

vec2 rot(vec2 v, float a) {
    float c = cos(a);
    float s = sin(a);
    return vec2(c * v.x - s * v.y, s * v.x + c * v.y);
}

vec3 tm(vec3 c) { return 1.0 - exp(-c * 1.2); }

float hgN(float c, float g) {
    float g2 = g * g;
    return (1.0 - g2) / pow(1.0 + g2 - 2.0 * g * c, 1.5);
}

uniform float Cover;
uniform float DayPhase;
uniform float Towering;
const float CB = 170.0;
const float CT = 430.0;

// pw: x,z — мировые координаты (+ смещение ветра), y — абсолютная высота
float cumDensity(vec3 pw, int oct) {
    float hf = (pw.y - CB) / (CT - CB);
    if (hf < 0.0 || hf > 1.0) return 0.0;
    float cov = fbm(vec3(pw.x * 0.0005, DayPhase, pw.z * 0.0005), 3);
    float thr = mix(0.62, 0.40, Cover);
    float gate = ss(thr - 0.07, thr + 0.07, cov);
    if (gate <= 0.0) return 0.0;
    float core = ss(thr, thr + 0.14, cov);               // 0 на краю облака, 1 в центре
    float hl = mix(mix(0.20, 0.42, Towering), mix(0.55, 1.0, Towering), core * core);              // вершина выше в центре — башенки
    float shape = ss(0.0, 0.06, hf) * ss(hl, hl * 0.35, hf);
    vec3 q = vec3(pw.x * 0.0075, pw.y * 0.0095, pw.z * 0.0075);
    q += (vnoise(q * 0.6 + vec3(1.7)) - 0.5) * 0.9;      // domain warp — бугры «цветной капусты»
    float n = fbm(q, oct);
    float d = gate * shape - (1.0 - n) * 0.55;
    d -= (1.0 - vnoise(q * 3.1)) * 0.10 * (1.0 - shape * gate);
    return clamp(d * 2.4, 0.0, 1.0);
}

// Объёмные кучевые: ray marching по слою CB..CT, плоское основание, освещение к солнцу, серебристая кромка.
vec4 cumulus(vec3 ro, vec3 v, int steps, float jit) {
    if (abs(v.y) < 0.004) return vec4(0.0);
    float ta = (CB - ro.y) / v.y;
    float tb = (CT - ro.y) / v.y;
    float t0 = max(min(ta, tb), 0.0);
    float t1 = min(max(ta, tb), 6000.0);
    if (t1 <= t0) return vec4(0.0);
    float dt = (t1 - t0) / float(steps);
    float c = dot(v, SunDir);
    float ph = min(mix(hgN(c, -0.2), hgN(c, 0.55), 0.4), 5.0);
    vec3 acc = vec3(0.0);
    float T = 1.0;
    for (int i = 0; i < 48; i++) {
        if (i >= steps) break;
        float t = t0 + dt * (float(i) + jit);
        vec3 p = ro + v * t;
        vec3 pw = vec3(p.x + WindOffset.x, p.y, p.z + WindOffset.y);
        float d = cumDensity(pw, 4);
        if (d > 0.01) {
            float tl = cumDensity(pw + SunDir * 40.0, 2) * 40.0 + cumDensity(pw + SunDir * 100.0, 2) * 60.0
                     + cumDensity(pw + SunDir * 200.0, 2) * 100.0;
            float E = exp(-tl * 0.028);
            float hf = (p.y - CB) / (CT - CB);
            float powder = 1.0 - exp(-d * 2.5);
            vec3 col = SunColor * (E * ph * mix(1.0, powder * 1.6, 0.35) + 0.30 * pow(E, 0.25)) * 0.9
                     + AmbientColor * mix(0.42, 1.0, hf) * (0.6 + 0.4 * E);
            col = mix(col, vec3(dot(col, vec3(0.333))) * vec3(0.62, 0.65, 0.68), Darkness * 0.8);
            col = mix(col, HorizonColor, 1.0 - exp(-t * 0.0002));
            float fade = 1.0 - ss(3000.0, 9000.0, t);
            float a = 1.0 - exp(-d * 0.04 * dt * fade);
            acc += T * a * col;
            T *= 1.0 - a;
            if (T < 0.03) break;
        }
    }
    float hz = ss(0.025, 0.10, abs(v.y));            // у горизонта растворяем: нет полос от грубых шагов
    return vec4(acc, 1.0 - T) * hz;
}

// Плоский облачный слой на высоте H: покрытие amt, анизотропная частота freq, thick — непрозрачность, bias — «сплошность».
vec4 sheet(vec3 ro, vec3 v, float H, float amt, vec2 freq, int oct, float soft, float thick,
           float darkMul, float wind, float bias) {
    if (amt < 0.02 || v.y < 0.012 || ro.y >= H) return vec4(0.0);
    float t = (H - ro.y) / v.y;
    vec2 xz = ro.xz + v.xz * t + WindOffset * wind;
    vec3 pp = vec3(xz * freq, Time * 0.004 + DayPhase * 2.0 + H * 0.01);
    float n = fbm(pp, oct) + bias;
    float thr = mix(0.72, 0.30, amt);
    float dd = ss(thr - soft, thr + soft, n);
    if (dd <= 0.0) return vec4(0.0);
    vec3 pp2 = vec3((xz + SunDir.xz * 80.0) * freq, pp.z);
    float n2 = fbm(pp2, max(oct - 1, 2)) + bias;
    float lit = clamp(0.62 - (n2 - n) * 3.0, 0.0, 1.0);
    vec3 litC = SunColor * 0.9 + AmbientColor * 0.7;
    vec3 shC = AmbientColor * 1.3 * darkMul;
    vec3 c = mix(shC, litC, lit);
    c = mix(c, vec3(dot(c, vec3(0.333))) * vec3(0.66, 0.68, 0.72), Darkness * 0.7);
    float fade = ss(0.012, 0.16, v.y) * (1.0 - ss(4000.0, 14000.0, t));
    float a = dd * thick * fade;
    return vec4(c * a, a);
}

void main() {
    vec4 far = InvViewProj * vec4(ndc, 1.0, 1.0);
    vec3 v = normalize(far.xyz / far.w);
    float y = v.y;

    float t = pow(clamp(y, 0.0, 1.0), 0.42);
    vec3 col = mix(HorizonColor, ZenithColor, t);
    col = mix(col, HorizonColor * 0.85, ss(0.0, -0.25, y));

    float sd = dot(v, SunDir);
    col += SunColor * (pow(max(sd, 0.0), 12.0) * 0.18 + pow(max(sd, 0.0), 220.0) * 0.9);
    vec2 vf = normalize(v.xz + vec2(1e-5));
    vec2 sf = normalize(SunDir.xz + vec2(1e-5));
    float az = max(dot(vf, sf), 0.0);
    col += GlowColor * pow(az, 3.0) * exp(-abs(y) * 5.0) * 0.8;
    col += GlowColor * 0.15 * exp(-abs(y) * 6.0);
    col += SunColor * 8.0 * ss(0.99905, 0.99935, sd) * step(-0.02, y);

    vec3 md = -SunDir;
    float mc = dot(v, md);
    float moon = ss(0.99880, 0.99900, mc) * step(0.0, y);
    float maria = vnoise(v * 38.0);
    col += vec3(0.85, 0.90, 1.0) * moon * (0.65 + 0.35 * maria) * Night * (1.0 - Darkness);
    col += vec3(0.25, 0.30, 0.45) * pow(max(mc, 0.0), 40.0) * 0.12 * Night * step(0.0, y);

    vec3 sp = v * 220.0;
    vec3 cell = floor(sp);
    float hs = hash13(cell);
    vec3 fr = fract(sp) - 0.5;
    float star = ss(0.9965, 1.0, hs) * ss(0.35, 0.0, length(fr));
    float tw = 0.75 + 0.25 * sin(Time * 3.0 + hs * 60.0);
    col += vec3(0.9, 0.95, 1.0) * star * tw * Night * ss(0.0, 0.2, y) * (1.0 - Darkness) * (1.0 - moon);

    if (AmbientCloud > 0.5) {
        vec4 L;
        // от высоких слоёв к низким
        L = sheet(CamPos, v, 1000.0, Mix2.y, vec2(0.0005), 2, 0.35, 0.40, 1.0, 0.5, 0.15);       // перистослоистые
        col = col * (1.0 - L.a) + L.rgb;
        float sa = acos(clamp(sd, -1.0, 1.0));
        float halo = exp(-pow((sa - 0.38) / 0.035, 2.0)) * Mix2.y * 0.30 * ss(0.0, 0.3, SunDir.y);
        col += SunColor * vec3(1.0, 0.85, 0.7) * halo * 0.6;                                       // гало 22°
        L = sheet(CamPos, v, 900.0, Mix2.x, vec2(0.0007, 0.0030), 4, 0.15, 0.55, 1.0, 0.6, 0.0);  // перистые
        col = col * (1.0 - L.a) + L.rgb;
        L = sheet(CamPos, v, 820.0, Mix2.z, vec2(0.010), 3, 0.10, 0.55, 1.0, 0.6, 0.0);           // перисто-кучевые
        col = col * (1.0 - L.a) + L.rgb;
        L = sheet(CamPos, v, 600.0, Mix1.w, vec2(0.0008), 3, 0.40, 0.65, 0.8, 0.7, 0.20);         // высокослоистые
        col = col * (1.0 - L.a) + L.rgb;
        L = sheet(CamPos, v, 520.0, Mix1.z, vec2(0.0045, 0.0030), 4, 0.12, 0.75, 0.85, 0.8, 0.0); // высококучевые
        col = col * (1.0 - L.a) + L.rgb;
        L = sheet(CamPos, v, 560.0, Mix2.w * 0.6, vec2(0.0012, 0.0035), 3, 0.06, 0.85, 0.8, 0.7, 0.0); // линзовидные
        col = col * (1.0 - L.a) + L.rgb;
        if (CumAmt > 0.03) {                                                                       // кучевые (объёмные)
            float jit = fract(52.9829189 * fract(dot(gl_FragCoord.xy, vec2(0.06711056, 0.00583715))));
            vec4 cu = cumulus(CamPos, v, int(CloudSteps), jit);
            col = col * (1.0 - cu.a) + cu.rgb;
        }
        L = sheet(CamPos, v, 150.0, Mix1.x, vec2(0.0030), 4, 0.10, 0.90, 0.7, 0.9, 0.0);          // слоисто-кучевые
        col = col * (1.0 - L.a) + L.rgb;
        L = sheet(CamPos, v, 125.0, Mix1.y, vec2(0.0006), 3, 0.50, 1.00, 0.65, 1.0, 0.25);        // слоистые
        col = col * (1.0 - L.a) + L.rgb;
    }

    col += vec3(0.50, 0.60, 0.85) * FlashAmt * 0.35 * ss(-0.1, 0.6, y);
    fragColor = vec4(tm(col), 1.0);
}
