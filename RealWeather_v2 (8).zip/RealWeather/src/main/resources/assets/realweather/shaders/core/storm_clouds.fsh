#version 150

uniform mat4 InvViewProj;
uniform sampler2D DepthSampler;
uniform vec3 CamPos;
uniform float Time;
uniform vec3 SunDir;
uniform vec3 SunColor;
uniform vec3 AmbientColor;
uniform vec3 HazeColor;
uniform float Steps;
uniform float StepScale;
uniform float MaxDist;
uniform float DetailOct;
uniform float LightSteps;
uniform float Density;
uniform float Contrast;
uniform float FlashAmt;
uniform vec3 FlashPos;
uniform float StormCount;
uniform float Darkness;

in vec2 ndc;
out vec4 fragColor;

float ss(float a, float b, float x) { return clamp((x - a) / (b - a), 0.0, 1.0); }

float hash13(vec3 p3) {
    p3 = fract(p3 * 0.1031);
    p3 += dot(p3, p3.zyx + 31.32);
    return fract((p3.x + p3.y) * p3.z);
}

float vnoise(vec3 x) {
    vec3 i = floor(x);
    vec3 f = fract(x);
    f = f * f * (3.0 - 2.0 * f);
    return mix(mix(mix(hash13(i), hash13(i + vec3(1, 0, 0)), f.x),
                   mix(hash13(i + vec3(0, 1, 0)), hash13(i + vec3(1, 1, 0)), f.x), f.y),
               mix(mix(hash13(i + vec3(0, 0, 1)), hash13(i + vec3(1, 0, 1)), f.x),
                   mix(hash13(i + vec3(0, 1, 1)), hash13(i + vec3(1, 1, 1)), f.x), f.y), f.z);
}

float fbm(vec3 p, int oct) {
    float a = 0.5;
    float s = 0.0;
    for (int i = 0; i < oct; i++) {
        s += a * vnoise(p);
        p = p * 2.02 + vec3(17.1, 3.7, 9.2);
        a *= 0.5;
    }
    return s;
}

vec2 rot(vec2 v, float a) {
    float c = cos(a);
    float s = sin(a);
    return vec2(c * v.x - s * v.y, s * v.x + c * v.y);
}

vec3 tm(vec3 c) { return 1.0 - exp(-c * 1.2); }

float hgN(float c, float g) {
    float g2 = g * g;
    return (1.0 - g2) / pow(1.0 + g2 - 2.0 * g * c, 1.5);
}

uniform float AnvilScale;
uniform float Realism;
uniform float FunnelScale;
uniform float SD[80];

struct StormInfo {
    vec2 c;
    float base;
    float top;
    float inten;
    float gr;
    vec2 dir;
    float tor;
    float gy;
    float R;
    float phase;
    vec2 tp;
    float rain;
    float shape;
    float meso;
    float type;
    vec2 up;
};

StormInfo getStorm(int i) {
    int o = i * 20;
    StormInfo s;
    s.c = vec2(SD[o], SD[o + 1]);
    s.base = SD[o + 2];
    s.top = SD[o + 3];
    s.inten = SD[o + 4];
    s.gr = SD[o + 5];
    s.dir = vec2(SD[o + 6], SD[o + 7]);
    s.tor = SD[o + 8];
    s.gy = SD[o + 9];
    s.R = SD[o + 10];
    s.phase = SD[o + 11];
    s.tp = vec2(SD[o + 12], SD[o + 13]);
    s.rain = SD[o + 14];
    s.shape = SD[o + 15];
    s.meso = SD[o + 16];
    s.type = SD[o + 17];
    s.up = vec2(SD[o + 18], SD[o + 19]);
    return s;
}

float towerMask(vec2 q, float h, float R, float grow, vec2 off, vec2 dir, float hs, float rs) {
    float h2 = h / hs;
    float hh2 = clamp(h2, 0.0, 1.0);
    vec2 qt2 = q - off - dir * (hh2 * hh2 * R * 0.35);
    float rt2 = R * rs * (0.85 + 0.45 * pow(hh2, 0.7)) * (0.5 + 0.5 * grow);
    rt2 *= mix(1.0, 0.40, ss(0.82, 1.10, h2));
    return ss(1.0, 0.10, length(qt2) / rt2) * ss(-0.03, 0.06, h2) * (1.0 - ss(0.96, 1.12, h2));
}

// Тело суперячейки как ЕДИНОЕ облако: апдрафт + широкое основание + толстая многослойная наковальня (мягкое объединение).
float cloudBody(vec3 p, StormInfo s, int oct, out float hOut) {
    hOut = 0.0;
    float R = s.R;
    float span = (s.top - s.base) * max(s.gr, 0.04);
    float h = (p.y - s.base) / span;
    hOut = clamp(h, 0.0, 1.0);
    if (h < -0.03 || h > 1.12 || s.gr < 0.02) return 0.0;

    vec2 q = p.xz - s.c;
    vec2 perp = vec2(-s.dir.y, s.dir.x);
    float hh = clamp(h, 0.0, 1.0);
    float grow = min(s.gr * 1.5, 1.0);

    // апдрафт: уже у основания, шире кверху, лёгкий наклон по ветру
    int ty = int(s.type + 0.5);                // 0 классика, 1 HP, 2 LP, 3 мультиячейка, 4 одиночная
    float rs = (ty == 2) ? 0.75 : ((ty == 1) ? 1.15 : ((ty == 3) ? 0.85 : 1.0));
    vec2 qt = q - s.up - s.dir * (hh * hh * R * 0.35);
    float mT = towerMask(q, h, R, grow, s.up, s.dir, 1.0, rs);
    if (ty == 3) {
        mT = max(mT, towerMask(q, h, R, grow, s.up + perp * R * 0.95 + s.dir * R * 0.25, s.dir, 0.72, 0.55));
        mT = max(mT, towerMask(q, h, R, grow, s.up - perp * R * 0.85 + s.dir * R * 0.55, s.dir, 0.55, 0.45));
    }

    // широкое плоское основание (область притока), плавно переходит в башню
    float rb = R * (0.6 + 0.9 * grow) * 3.6 * ((ty == 1) ? 1.3 : 1.0);
    float mB = ss(1.0, 0.15, length(q - s.dir * R * 0.2) / rb) * ss(-0.03, 0.03, h) * (1.0 - ss(0.06, 0.20, h));

    // наковальня: огромная, толстая в центре, тонкая неровная периферия, свес и против ветра, слои
    float mA = 0.0;
    float ag = ss(0.45, 0.95, s.gr);
    if (ag > 0.01) {
        float a = max(R * (1.0 + 3.2 * AnvilScale) * ag, 1.0);
        float ash = (ty == 0) ? 0.40 : ((ty == 1) ? 0.30 : ((ty == 2) ? 0.45 : ((ty == 3) ? 0.25 : 0.0)));
        vec2 qa = q - s.up - s.dir * (ash * a);                // центр наковальни — над столбом, сдвинут по ветру
        float u = dot(qa, s.dir) / a;
        float v = dot(qa, perp) / (a * 0.75);
        float usemi = (ty == 4) ? 1.0 : (ash + 0.22);          // наветренный край заходит за столб — наковальня на нём
        u = (u < 0.0) ? u / usemi : u;
        float e = length(vec2(u, v));
        float mm = vnoise(vec3(q * 0.03, 1.0));
        float hL = mix(0.84, 0.52, clamp(1.0 - e, 0.0, 1.0)) + (mm - 0.5) * 0.10;
        float hU = 0.99 - 0.06 * e;
        float lay = ss(hL, hL + 0.10, h) * (1.0 - ss(hU - 0.06, hU, h));
        lay *= 0.85 + 0.15 * sin(h * 38.0 + mm * 6.0);
        mA = ss(1.0, 0.05, e) * lay;
    }

    float mask = 1.0 - (1.0 - mT) * (1.0 - mB) * (1.0 - mA);
    if (mask < 0.002) return 0.0;
    float aw = mA / (mT + mB + mA + 1e-4);
    float bw = mB / (mT + mB + mA + 1e-4);

    vec2 qr = q;
    vec3 nc = vec3(qr.x, p.y * 1.5, qr.y) / (R * 0.4);
    nc += (vnoise(nc * 0.7 + vec3(3.0)) - 0.5) * 0.8;
    float n1 = fbm(nc, oct);
    float er = 0.30 + 0.28 * Realism;
    float d = mask - (1.0 - n1) * er * (1.0 - 0.45 * aw - 0.5 * bw);
    if (oct > 2) d -= (1.0 - fbm(nc * 3.7 + vec3(5.2, 1.3, 8.8), oct - 1)) * (0.06 + 0.20 * Realism) * (1.0 - 0.5 * mask) * (1.0 - 0.65 * aw);
    float ang = atan(qt.y, qt.x);
    float band = 0.5 + 0.5 * sin(ang * 5.0 - hh * 8.0 + s.phase * 1.5);
    d *= mix(1.0, 0.70 + 0.60 * band, ss(0.15, 0.6, hh) * (1.0 - aw) * 0.5);
    return clamp(d * 2.1, 0.0, 1.0);
}

vec2 boxHit(vec3 ro, vec3 rd, vec3 bmin, vec3 bmax) {
    vec3 sg = vec3(rd.x < 0.0 ? -1.0 : 1.0, rd.y < 0.0 ? -1.0 : 1.0, rd.z < 0.0 ? -1.0 : 1.0);
    vec3 inv = sg / max(abs(rd), vec3(1e-5));
    vec3 t0 = (bmin - ro) * inv;
    vec3 t1 = (bmax - ro) * inv;
    vec3 tn = min(t0, t1);
    vec3 tf = max(t0, t1);
    return vec2(max(max(tn.x, tn.y), tn.z), min(min(tf.x, tf.y), tf.z));
}

float distSeg(vec2 p, vec2 a, vec2 b) {
    vec2 pa = p - a;
    vec2 ba = b - a;
    float h = clamp(dot(pa, ba) / max(dot(ba, ba), 1e-3), 0.0, 1.0);
    return length(pa - ba * h);
}

// Wall cloud (широкий опущенный «пьедестал» основания), tail cloud, воронка (врастает в пьедестал), пыль, дождь.
float extras(vec3 p, StormInfo s, int oct, out float rainD, out float dustD, out float funD) {
    rainD = 0.0;
    dustD = 0.0;
    funD = 0.0;
    float dens = 0.0;
    float R = s.R;
    float lowF = max(s.tor, s.meso * 0.8);
    float low = 25.0 + 75.0 * lowF;
    float rw = R * 0.12 + R * 0.20 * lowF;

    if (lowF > 0.05 && s.gr > 0.3) {
        float yw = (s.base - p.y) / low;
        vec2 qw = p.xz - s.tp;
        float lw = length(qw);
        float rwd = rw * (1.0 - 0.5 * clamp(yw, 0.0, 1.0));
        if (yw > -0.2 && yw < 1.05 && lw < rwd * 1.2) {
            float mW = ss(1.0, 0.2, lw / rwd) * ss(-0.2, 0.12, yw) * (1.0 - ss(0.78, 1.02, yw));
            float nW = fbm(vec3(qw.x, p.y * 2.0, qw.y) / (rw * 0.45), min(oct, 3));
            nW *= 0.8 + 0.4 * sin(atan(qw.y, qw.x) * 3.0 - p.y * 0.08 + s.phase * 2.0);
            dens += clamp((mW - (1.0 - nW) * 0.45) * 2.2, 0.0, 1.0) * ss(0.3, 0.6, s.gr) * (0.4 + 0.6 * s.inten) * ss(0.05, 0.35, lowF);
        }
        // tail cloud: низкая тонкая лента от wall cloud в сторону дождевого ядра
        vec2 tend = s.c + s.dir * R * 1.4;
        float dsg = distSeg(p.xz, s.tp, tend);
        float ty = (s.base - p.y) / (30.0 + 40.0 * lowF);
        float wid = R * 0.05 + 6.0;
        if (ty > -0.3 && ty < 1.1 && dsg < wid * 1.5) {
            float mt = ss(1.0, 0.15, dsg / wid) * ss(-0.3, 0.15, ty) * (1.0 - ss(0.7, 1.05, ty));
            float nt = vnoise(vec3(p.xz * 0.04, p.y * 0.05 + Time * 0.1));
            dens += clamp((mt - (1.0 - nt) * 0.4) * 2.0, 0.0, 1.0) * 0.8 * ss(0.15, 0.5, lowF);
        }
    }

    if (s.tor > 0.02) {
        float reach = ss(0.05, 0.35, s.tor);
        float bottom = mix(s.gy + (s.base - s.gy) * 0.55, s.gy, reach);
        float topF = s.base - low * 0.7;               // верх воронки внутри пьедестала: нет зазора
        float ft = (p.y - bottom) / max(topF - bottom, 1.0);
        if (ft > -0.02 && ft < 1.08) {
            float ftc = clamp(ft, 0.0, 1.0);
            vec2 sway = vec2(sin(p.y * 0.045 + Time * 0.8), cos(p.y * 0.031 + Time * 0.6))
                      * (1.5 + 9.0 * ftc * ftc) * (1.2 - 0.6 * s.tor);
            vec2 fperp = vec2(-s.dir.y, s.dir.x);
            vec2 axis = s.tp + sway + fperp * sin((1.0 - ftc) * 2.2) * R * 0.08 * (0.4 + 0.6 * s.tor);
            vec2 dv = p.xz - axis;
            float dr = length(dv);
            // shape: 0 = верёвка, ~0.4 = конус, ~0.65 = труба, 1 = клин
            float r1 = (rw * 0.55 + 4.0) * mix(0.55, 1.25, s.shape) * FunnelScale;
            float r0 = mix(1.0 + 2.0 * s.tor, r1 * 0.45, pow(s.shape, 1.5));
            float rf = mix(r0, r1, pow(ftc, mix(3.0, 0.7, s.shape)));
            rf *= 1.0 + 0.06 * sin(Time * 2.3 + p.y * 0.05);
            float a = atan(dv.y, dv.x) + Time * (2.2 + 3.0 * s.tor) / (1.0 + ftc * 1.5) + p.y * 0.05;
            float nf = vnoise(vec3(cos(a) * 2.5, sin(a) * 2.5, p.y * 0.07 - Time * 0.9));
            float nf2 = vnoise(vec3(cos(a * 3.0) * 6.0, sin(a * 3.0) * 6.0, p.y * 0.02 - Time * 0.6));
            float nf3 = vnoise(vec3(cos(a * 5.0) * 9.0, sin(a * 5.0) * 9.0, p.y * 0.16 - Time * 1.8));
            float rr = dr * (1.0 + 0.40 * (nf - 0.5) + 0.20 * (nf2 - 0.5) + 0.12 * (nf3 - 0.5));
            float m = ss(rf, rf * 0.82, rr) * ss(-0.02, 0.06, ft) * (1.0 - ss(1.0, 1.08, ft));
            funD = m * (0.70 + 0.45 * nf + 0.30 * nf2 + 0.25 * nf3) * ss(0.02, 0.3, s.tor) * 4.0;
            if (s.shape > 0.6 && s.tor > 0.55) {          // клин сильного торнадо: суб-вихри вокруг оси
                float sv = 0.0;
                for (int k = 0; k < 3; k++) {
                    float ak = Time * 1.7 + float(k) * 2.0944 + p.y * 0.03;
                    vec2 off = vec2(cos(ak), sin(ak)) * rf * 0.65;
                    float dk = length(dv - off);
                    sv = max(sv, ss(rf * 0.38, rf * 0.14, dk));
                }
                funD += sv * ss(0.0, 0.2, ft) * (1.0 - ss(0.9, 1.0, ft)) * 1.6 * ss(0.55, 0.8, s.tor);
            }
            dens += funD;
        }
        float hg = p.y - s.gy;
        if (hg > -3.0 && hg < 60.0 * (0.5 + s.tor)) {
            vec2 dq = p.xz - s.tp;
            float dr = length(dq);
            float rd = 14.0 + R * 0.30 * s.tor;
            float md = ss(rd * (1.0 + hg * 0.02), rd * 0.15, dr) * (1.0 - ss(0.0, 50.0 * (0.4 + s.tor), hg));
            if (md > 0.01) {
                float nd = fbm(vec3(rot(dq, Time * 1.5) * 0.06, p.y * 0.05), 3);
                float arm = 0.65 + 0.35 * sin(atan(dq.y, dq.x) * 3.0 - dr * 0.12 + Time * 3.0);
                dustD = md * s.tor * (0.4 + nd) * arm * 1.9;
                dens += dustD * 0.9;
            }
        }
    }

    // стадия «тёплого пузыря»: видимый поднимающийся столб тёплого воздуха от земли до основания, шире кверху
    float early = ss(0.30, 0.08, s.gr);
    if (early > 0.02 && p.y > s.gy && p.y < s.base + 40.0) {
        vec2 qp = p.xz - (s.c + s.up);
        float rp = R * (0.35 + 0.40 * clamp((p.y - s.gy) / max(s.base - s.gy, 1.0), 0.0, 1.0));
        float lpp = length(qp);
        if (lpp < rp * 1.2) {
            float mP = ss(1.0, 0.1, lpp / rp) * ss(s.gy, s.gy + 30.0, p.y) * (1.0 - ss(s.base, s.base + 40.0, p.y));
            float nP = fbm(vec3(qp.x * 0.02, p.y * 0.015 - Time * 0.7, qp.y * 0.02), 3);
            dens += clamp((mP - (1.0 - nP) * 0.7) * 1.6, 0.0, 1.0) * 0.35 * early;
        }
    }

    if (s.gr > 0.5) {
        // arcus: полка по переднему краю (фронт порывов)
        vec2 qa = p.xz - s.c;
        float rr = max(length(qa), 1.0);
        float edge = abs(rr - R * 1.5) / (R * 0.18);
        float front = ss(-0.2, 0.5, dot(qa, s.dir) / rr);
        float ay = (s.base - p.y) / 35.0;
        if (edge < 1.2 && ay > -0.4 && ay < 1.2 && front > 0.0) {
            float m = ss(1.0, 0.0, edge) * front * ss(-0.4, 0.15, ay) * (1.0 - ss(0.6, 1.1, ay));
            float na = fbm(vec3(qa * 0.015, p.y * 0.04), 3);
            dens += clamp((m - (1.0 - na) * 0.5) * 1.8, 0.0, 1.0) * 0.7 * ss(0.4, 0.8, s.inten) * ss(0.6, 0.9, s.gr);
        }
        // scud (fractus): рваные клочья под основанием около зоны притока
        float sy = (s.base - p.y) / 60.0;
        if (sy > 0.0 && sy < 1.0) {
            vec2 qs = p.xz - (s.c - s.dir * R * 0.2);
            float ls = length(qs);
            if (ls < R * 1.4) {
                float ns = fbm(vec3(qs * 0.012, p.y * 0.03 + Time * 0.05), 3);
                float ms = ss(R * 1.4, R * 0.6, ls) * ss(0.0, 0.2, sy) * (1.0 - ss(0.7, 1.0, sy));
                dens += clamp(ms * (ns - 0.45) * 3.0, 0.0, 1.0) * 0.6 * ss(0.3, 0.7, s.inten);
            }
        }
    }

    if (s.rain > 0.01 && p.y < s.base && p.y > s.gy - 4.0) {
        vec2 rq = p.xz - (s.c + s.dir * R * 0.60);
        float rrad = R * 0.45;
        float lr = length(rq);
        if (lr < rrad) {
            float mR = ss(1.0, 0.0, lr / rrad);
            mR = mR * mR;
            float nr = vnoise(vec3(rq.x * 0.07, p.y * 0.012 + Time * 0.8, rq.y * 0.07));
            rainD = mR * s.rain * s.inten * (0.25 + 0.75 * nr) * 0.22 * ss(s.base, s.base - 25.0, p.y) * ss(s.gy - 4.0, s.gy + 12.0, p.y);
            dens += rainD;
        }
    }
    return dens;
}

void main() {
    vec4 far = InvViewProj * vec4(ndc, 1.0, 1.0);
    vec3 rd = normalize(far.xyz / far.w);
    vec3 ro = vec3(0.0, CamPos.y, 0.0);   // xz — относительно камеры, y — абсолютный

    float tDepth = 1e9;
    float dsmp = texture(DepthSampler, ndc * 0.5 + 0.5).r;
    if (dsmp < 0.99999) {
        vec4 wp = InvViewProj * vec4(ndc, dsmp * 2.0 - 1.0, 1.0);
        tDepth = length(wp.xyz / wp.w);
    }

    int n = int(StormCount);
    float tmin = 1e9;
    float tmax = -1e9;
    for (int i = 0; i < 4; i++) {
        if (i >= n) break;
        StormInfo s = getStorm(i);
        float Rb = s.R * (3.2 + 4.4 * AnvilScale);
        vec3 bmin = vec3(s.c.x - Rb, s.gy - 6.0, s.c.y - Rb);
        vec3 bmax = vec3(s.c.x + Rb, s.top + s.R * 0.15, s.c.y + Rb);
        vec2 hit = boxHit(ro, rd, bmin, bmax);
        if (hit.y > hit.x && hit.y > 0.0) {
            tmin = min(tmin, max(hit.x, 0.0));
            tmax = max(tmax, hit.y);
        }
    }
    tmax = min(tmax, min(tDepth, MaxDist));
    if (tmax <= tmin) {
        fragColor = vec4(0.0);
        return;
    }

    int oct = int(DetailOct);
    int lsteps = int(LightSteps);
    float jit = fract(52.9829189 * fract(dot(gl_FragCoord.xy, vec2(0.06711056, 0.00583715))));
    float t = tmin + jit * clamp(tmin * StepScale, 4.0, 45.0);

    vec3 acc = vec3(0.0);
    float T = 1.0;
    float cosSun = dot(rd, SunDir);
    float phase = min(mix(hgN(cosSun, -0.2), hgN(cosSun, 0.62), 0.35), 6.0);

    float used = 0.0;
    for (int i = 0; i < 256; i++) {
        if (used >= Steps * 1.5 || t > tmax) break;
        vec3 p = ro + rd * t;

        float dens = 0.0;
        float rainS = 0.0;
        float dustS = 0.0;
        float funS = 0.0;
        float hTop = 0.0;
        float best = 0.0;
        int bi = 0;
        bool nearTor = false;
        for (int k = 0; k < 4; k++) {
            if (k >= n) break;
            StormInfo s = getStorm(k);
            if (s.tor > 0.05 && p.y < s.base && length(p.xz - s.tp) < 130.0) nearTor = true;
            float h0;
            float r0;
            float du0;
            float fu0;
            float d = cloudBody(p, s, oct, h0);
            d += extras(p, s, oct, r0, du0, fu0);
            if (d > best) {
                best = d;
                bi = k;
                hTop = h0;
            }
            dens += d;
            rainS += r0;
            dustS += du0;
            funS += fu0;
        }

        float sl = clamp(t * StepScale, 4.0, 45.0);
        if (nearTor) sl = min(sl, 2.0);       // тонкий шаг у воронки — без размазывания
        used += nearTor ? 0.3 : 1.0;

        if (dens > 0.003) {
            StormInfo s = getStorm(bi);
            float tauL = 0.0;
            for (int j = 1; j <= 4; j++) {
                if (j > lsteps) break;
                float hh;
                float dd = 30.0 * pow(2.1, float(j - 1));
                tauL += cloudBody(p + SunDir * dd, s, 2, hh) * dd * 0.5;
            }
            float E = exp(-tauL * 0.015 * Density);
            float lit = E * phase + 0.30 * pow(E, 0.25);       // прямой свет + грубое многократное рассеяние
            float f = clamp(dens, 0.0, 1.0);
            float rf = clamp(rainS / max(dens, 1e-3), 0.0, 1.0);
            float df = clamp(dustS / max(dens, 1e-3), 0.0, 1.0);
            float ff = clamp(funS / max(dens, 1e-3), 0.0, 1.0);

            vec3 albedo = vec3(1.0);
            albedo = mix(albedo, vec3(0.50, 0.54, 0.58), rf * 0.8);
            albedo = mix(albedo, vec3(0.46, 0.35, 0.25), df * 0.85);
            albedo = mix(albedo, vec3(0.78, 0.80, 0.84), ff * 0.7);

            float rainLoad = clamp(s.rain * s.inten * 1.3, 0.0, 1.0);   // накопленный дождь
            float under = pow(1.0 - hTop, 1.5);
            float ambF = mix(0.45, 1.0, ss(0.0, 0.8, hTop));
            ambF *= mix(1.0, 0.20, clamp(s.inten * 0.4 + rainLoad * 0.6, 0.0, 1.0) * under);
            vec3 amb = AmbientColor * ambF * mix(0.55, 1.0, E) * (1.0 + 1.5 * ff);
            vec3 sunL = SunColor * lit * Contrast * (0.8 + 0.4 * Realism) * 0.85 * mix(1.0, 0.30, rainLoad * under);
            vec3 fl = vec3(0.65, 0.78, 1.0) * FlashAmt * exp(-length(p - FlashPos) / 420.0) * (2.0 + 3.0 * under);

            vec3 col = albedo * (sunL + amb + fl);
            col *= mix(vec3(1.0), vec3(0.92, 1.0, 0.90), s.inten * 0.35 * (1.0 - hTop));
            col = mix(col, HazeColor, (1.0 - exp(-t * 0.00030)) * 0.6);

            float fade = 1.0 - ss(0.7 * MaxDist, MaxDist, t);
            float sigma = f * 0.06 * Density * fade;
            float a = 1.0 - exp(-sigma * sl);
            acc += T * a * col;
            T *= (1.0 - a);
            if (T < 0.02) break;
            t += sl * 0.75;
        } else {
            t += sl * 1.5;
        }
    }

    fragColor = vec4(tm(acc), 1.0 - T);
}
